# Extensible Multi-Floor Parking Lot System (Java)

This project is a console-based parking lot application built with Java, following clean OOP principles.

## Features
- **Multiple Floors & Slot Types**: The system supports multiple floors, and slots are typed to specific vehicle types (BIKE, CAR, TRUCK).
- **Vehicle Types**: Supports BIKE, CAR, and TRUCK.
- **Operations**:
  - Park a vehicle (allocates nearest slot, generates ticket).
  - Unpark a vehicle (calculates fee based on duration and vehicle type, frees the slot).
  - Display free slots for a specific vehicle type on all floors.
- **Validations**:
  - Prevents duplicate vehicle parking.
  - Rejects invalid or previously processed tickets.
  - Handles slot unavailability gracefully.

## Design Decisions
- **Enums**: Used for `VehicleType` to avoid magic strings and enable type safety.
- **Design Patterns**:
  1. **Strategy Pattern**: 
     - `SlotAllocationStrategy`: Allows different strategies for assigning slots (e.g., `NearestSlotAllocationStrategy`). If we want a new strategy (like VIP slots first, or random slots), we only need to implement this interface.
     - `FeeStrategy`: Different algorithms to calculate parking fees. Currently using `DefaultFeeStrategy`, but easy to add dynamic pricing, weekend pricing, etc.
  2. **Factory Pattern**:
     - `FeeStrategyFactory`: Used to instantiate and provide the appropriate `FeeStrategy`. Simplifies the logic in the service layer when determining which fee strategy to apply.

## UML Diagram
![Handwritten UML Diagram](UML-Diagram.png)

## Project Structure
```text
ParkingLotJava/
├── src/
│   ├── main/java/com/parkinglot/
│   │   ├── Main.java
│   │   ├── enums/
│   │   │   └── VehicleType.java
│   │   ├── exceptions/
│   │   │   ├── DuplicateVehicleException.java
│   │   │   ├── InvalidTicketException.java
│   │   │   └── SlotUnavailableException.java
│   │   ├── models/
│   │   │   ├── ParkingFloor.java
│   │   │   ├── ParkingLot.java
│   │   │   ├── ParkingSlot.java
│   │   │   ├── Ticket.java
│   │   │   └── Vehicle.java
│   │   ├── services/
│   │   │   └── ParkingLotService.java
│   │   └── strategies/
│   │       ├── DefaultFeeStrategy.java
│   │       ├── FeeStrategy.java
│   │       ├── FeeStrategyFactory.java
│   │       ├── NearestSlotAllocationStrategy.java
│   │       └── SlotAllocationStrategy.java
│   └── test/java/com/parkinglot/
│       └── ParkingLotServiceTest.java
├── README.md
├── UML.md
└── sample_output.txt
```
## Execution
Run the `Main.java` class to see a demonstration of normal and edge-case operations.
Run `ParkingLotServiceTest.java` to execute unit/functional tests.

## Sample Output
![Terminal Screenshot](outputimage.png)

```text
Parked Car 1. Ticket: PRK1_1_1
Parked Car 2. Ticket: PRK1_1_2
Free slots for CAR on Floor 1:
Free slots for CAR on Floor 2: 2, 
Unparked Car 1. Fee: 40.0
Free slots for CAR on Floor 1: 1, 
Free slots for CAR on Floor 2: 2, 
Error: Invalid or already processed ticket!
Error: Invalid or already processed ticket!
Error: Vehicle is already parked!

Free slots for CAR on Floor 1: 1, 
All basic tests passed successfully.
```
