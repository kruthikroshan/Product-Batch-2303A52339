package com.parkinglot.strategies;
import com.parkinglot.models.Ticket;
import java.time.LocalDateTime;

public interface FeeStrategy {
    double calculateFee(Ticket ticket, LocalDateTime exitTime);
}
