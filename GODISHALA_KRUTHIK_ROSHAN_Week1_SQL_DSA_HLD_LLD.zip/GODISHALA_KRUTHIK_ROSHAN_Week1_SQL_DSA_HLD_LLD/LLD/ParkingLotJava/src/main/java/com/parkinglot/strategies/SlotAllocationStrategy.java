package com.parkinglot.strategies;
import com.parkinglot.models.ParkingLot;
import com.parkinglot.models.ParkingSlot;
import com.parkinglot.enums.VehicleType;

public interface SlotAllocationStrategy {
    ParkingSlot findSlot(ParkingLot parkingLot, VehicleType vehicleType);
}
