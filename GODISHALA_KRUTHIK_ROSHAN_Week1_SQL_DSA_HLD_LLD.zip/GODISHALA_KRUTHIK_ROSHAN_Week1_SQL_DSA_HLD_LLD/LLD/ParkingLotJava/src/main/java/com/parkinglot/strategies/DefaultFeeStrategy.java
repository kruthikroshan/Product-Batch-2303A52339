package com.parkinglot.strategies;
import com.parkinglot.models.Ticket;
import java.time.LocalDateTime;
import java.time.Duration;

public class DefaultFeeStrategy implements FeeStrategy {
    @Override
    public double calculateFee(Ticket ticket, LocalDateTime exitTime) {
        long hours = Duration.between(ticket.getEntryTime(), exitTime).toHours();
        if (hours == 0) hours = 1; // Minimum 1 hour charge
        
        switch (ticket.getVehicle().getType()) {
            case BIKE: return hours * 10.0;
            case CAR: return hours * 20.0;
            case TRUCK: return hours * 50.0;
            default: return 0.0;
        }
    }
}
