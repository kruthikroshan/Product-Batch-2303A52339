package com.parkinglot.models;
import com.parkinglot.enums.VehicleType;

public class Vehicle {
    private String registrationNumber;
    private String color;
    private VehicleType type;

    public Vehicle(String registrationNumber, String color, VehicleType type) {
        this.registrationNumber = registrationNumber;
        this.color = color;
        this.type = type;
    }

    public String getRegistrationNumber() { return registrationNumber; }
    public VehicleType getType() { return type; }
    public String getColor() { return color; }
}
