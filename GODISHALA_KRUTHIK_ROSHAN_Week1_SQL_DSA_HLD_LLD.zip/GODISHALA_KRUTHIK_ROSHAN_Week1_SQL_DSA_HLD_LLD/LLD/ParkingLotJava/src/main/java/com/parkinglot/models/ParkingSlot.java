package com.parkinglot.models;
import com.parkinglot.enums.VehicleType;

public class ParkingSlot {
    private int floorNumber;
    private int slotNumber;
    private VehicleType allowedVehicleType;
    private boolean isFree;
    private Vehicle vehicle;

    public ParkingSlot(int floorNumber, int slotNumber, VehicleType allowedVehicleType) {
        this.floorNumber = floorNumber;
        this.slotNumber = slotNumber;
        this.allowedVehicleType = allowedVehicleType;
        this.isFree = true;
    }

    public boolean isFree() { return isFree; }
    public VehicleType getAllowedVehicleType() { return allowedVehicleType; }
    public int getFloorNumber() { return floorNumber; }
    public int getSlotNumber() { return slotNumber; }
    public Vehicle getVehicle() { return vehicle; }

    public void parkVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
        this.isFree = false;
    }

    public void removeVehicle() {
        this.vehicle = null;
        this.isFree = true;
    }
}
