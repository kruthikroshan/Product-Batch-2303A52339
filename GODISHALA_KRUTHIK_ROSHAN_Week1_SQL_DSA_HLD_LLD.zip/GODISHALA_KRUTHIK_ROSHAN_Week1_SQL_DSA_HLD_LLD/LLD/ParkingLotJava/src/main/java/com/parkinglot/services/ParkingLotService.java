package com.parkinglot.services;
import com.parkinglot.models.*;
import com.parkinglot.enums.VehicleType;
import com.parkinglot.strategies.SlotAllocationStrategy;
import com.parkinglot.strategies.FeeStrategyFactory;
import com.parkinglot.exceptions.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.HashSet;
import java.util.Set;

public class ParkingLotService {
    private ParkingLot parkingLot;
    private SlotAllocationStrategy allocationStrategy;
    private Map<String, Ticket> activeTickets = new HashMap<>();
    private Set<String> parkedVehicles = new HashSet<>();
    private int ticketCounter = 1;

    public ParkingLotService(ParkingLot parkingLot, SlotAllocationStrategy allocationStrategy) {
        this.parkingLot = parkingLot;
        this.allocationStrategy = allocationStrategy;
    }

    public Ticket parkVehicle(Vehicle vehicle) {
        if (parkedVehicles.contains(vehicle.getRegistrationNumber())) {
            throw new DuplicateVehicleException("Vehicle is already parked!");
        }

        ParkingSlot slot = allocationStrategy.findSlot(parkingLot, vehicle.getType());
        slot.parkVehicle(vehicle);

        String ticketId = parkingLot.getParkingLotId() + "_" + slot.getFloorNumber() + "_" + slot.getSlotNumber();
        Ticket ticket = new Ticket(ticketId, vehicle, slot, LocalDateTime.now());
        
        activeTickets.put(ticketId, ticket);
        parkedVehicles.add(vehicle.getRegistrationNumber());
        return ticket;
    }

    public double unparkVehicle(String ticketId) {
        if (!activeTickets.containsKey(ticketId)) {
            throw new InvalidTicketException("Invalid or already processed ticket!");
        }

        Ticket ticket = activeTickets.get(ticketId);
        ParkingSlot slot = ticket.getParkingSlot();
        
        slot.removeVehicle();
        activeTickets.remove(ticketId);
        parkedVehicles.remove(ticket.getVehicle().getRegistrationNumber());

        return FeeStrategyFactory.getFeeStrategy().calculateFee(ticket, LocalDateTime.now().plusHours(2)); // Simulating 2 hours
    }

    public void displayFreeSlots(VehicleType vehicleType) {
        for (ParkingFloor floor : parkingLot.getFloors()) {
            System.out.print("Free slots for " + vehicleType + " on Floor " + floor.getFloorNumber() + ": ");
            for (ParkingSlot slot : floor.getSlots()) {
                if (slot.isFree() && slot.getAllowedVehicleType() == vehicleType) {
                    System.out.print(slot.getSlotNumber() + ", ");
                }
            }
            System.out.println();
        }
    }
}
