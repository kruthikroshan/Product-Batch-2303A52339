package com.parkinglot.strategies;
// Using Factory Pattern for Fee Strategy
public class FeeStrategyFactory {
    public static FeeStrategy getFeeStrategy() {
        return new DefaultFeeStrategy();
    }
}
