package com.parkinglot;
import com.parkinglot.enums.VehicleType;
import com.parkinglot.models.*;
import com.parkinglot.services.ParkingLotService;
import com.parkinglot.strategies.NearestSlotAllocationStrategy;

public class Main {
    public static void main(String[] args) {
        ParkingLot lot = new ParkingLot("PRK1");
        ParkingFloor floor1 = new ParkingFloor(1);
        floor1.addSlot(new ParkingSlot(1, 1, VehicleType.CAR));
        floor1.addSlot(new ParkingSlot(1, 2, VehicleType.CAR));
        floor1.addSlot(new ParkingSlot(1, 3, VehicleType.BIKE));
        
        ParkingFloor floor2 = new ParkingFloor(2);
        floor2.addSlot(new ParkingSlot(2, 1, VehicleType.TRUCK));
        floor2.addSlot(new ParkingSlot(2, 2, VehicleType.CAR));

        lot.addFloor(floor1);
        lot.addFloor(floor2);

        ParkingLotService service = new ParkingLotService(lot, new NearestSlotAllocationStrategy());

        try {
            // 1. Park Car 1
            Vehicle car1 = new Vehicle("KA-01-1234", "Red", VehicleType.CAR);
            Ticket t1 = service.parkVehicle(car1);
            System.out.println("Parked Car 1. Ticket: " + t1.getTicketId());

            // 2. Park Car 2
            Vehicle car2 = new Vehicle("KA-01-5678", "Blue", VehicleType.CAR);
            Ticket t2 = service.parkVehicle(car2);
            System.out.println("Parked Car 2. Ticket: " + t2.getTicketId());

            // 3. Display free CAR slots
            service.displayFreeSlots(VehicleType.CAR);

            // 4. Unpark Car 1
            double fee = service.unparkVehicle(t1.getTicketId());
            System.out.println("Unparked Car 1. Fee: " + fee);

            // 5. Display free CAR slots again
            service.displayFreeSlots(VehicleType.CAR);

            // 6. Test invalid ticket
            try {
                service.unparkVehicle("INVALID_TICKET");
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
            
            // 7. Test repeated exit
            try {
                service.unparkVehicle(t1.getTicketId());
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }

            // 8. Test duplicate vehicle
            try {
                service.parkVehicle(car2);
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
