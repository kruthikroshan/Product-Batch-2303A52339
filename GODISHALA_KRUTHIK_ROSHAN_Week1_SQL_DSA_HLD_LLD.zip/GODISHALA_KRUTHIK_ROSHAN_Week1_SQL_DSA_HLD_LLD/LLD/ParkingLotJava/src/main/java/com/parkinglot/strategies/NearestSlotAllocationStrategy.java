package com.parkinglot.strategies;
import com.parkinglot.models.ParkingFloor;
import com.parkinglot.models.ParkingLot;
import com.parkinglot.models.ParkingSlot;
import com.parkinglot.enums.VehicleType;
import com.parkinglot.exceptions.SlotUnavailableException;

public class NearestSlotAllocationStrategy implements SlotAllocationStrategy {
    @Override
    public ParkingSlot findSlot(ParkingLot parkingLot, VehicleType vehicleType) {
        for (ParkingFloor floor : parkingLot.getFloors()) {
            for (ParkingSlot slot : floor.getSlots()) {
                if (slot.isFree() && slot.getAllowedVehicleType() == vehicleType) {
                    return slot;
                }
            }
        }
        throw new SlotUnavailableException("No free slots available for " + vehicleType);
    }
}
