package com.parkinglot;
import com.parkinglot.enums.VehicleType;
import com.parkinglot.models.*;
import com.parkinglot.services.ParkingLotService;
import com.parkinglot.strategies.NearestSlotAllocationStrategy;
import com.parkinglot.exceptions.*;

public class ParkingLotServiceTest {
    public static void main(String[] args) {
        testParkVehicleSuccess();
        testDuplicateVehicle();
        testSlotUnavailable();
        testUnparkSuccess();
        testInvalidTicket();
        testRepeatedExit();
        testDisplayFreeSlots();
        System.out.println("All basic tests passed successfully.");
    }

    private static ParkingLotService setupService() {
        ParkingLot lot = new ParkingLot("TEST");
        ParkingFloor floor = new ParkingFloor(1);
        floor.addSlot(new ParkingSlot(1, 1, VehicleType.CAR));
        lot.addFloor(floor);
        return new ParkingLotService(lot, new NearestSlotAllocationStrategy());
    }

    static void testParkVehicleSuccess() {
        ParkingLotService s = setupService();
        Ticket t = s.parkVehicle(new Vehicle("V1", "Red", VehicleType.CAR));
        if (t == null) throw new RuntimeException("Test Failed");
    }

    static void testDuplicateVehicle() {
        ParkingLotService s = setupService();
        Vehicle v = new Vehicle("V1", "Red", VehicleType.CAR);
        s.parkVehicle(v);
        try {
            s.parkVehicle(v);
            throw new RuntimeException("Test Failed");
        } catch (DuplicateVehicleException e) { }
    }

    static void testSlotUnavailable() {
        ParkingLotService s = setupService();
        s.parkVehicle(new Vehicle("V1", "Red", VehicleType.CAR));
        try {
            s.parkVehicle(new Vehicle("V2", "Blue", VehicleType.CAR));
            throw new RuntimeException("Test Failed");
        } catch (SlotUnavailableException e) { }
    }

    static void testUnparkSuccess() {
        ParkingLotService s = setupService();
        Ticket t = s.parkVehicle(new Vehicle("V1", "Red", VehicleType.CAR));
        s.unparkVehicle(t.getTicketId());
    }

    static void testInvalidTicket() {
        ParkingLotService s = setupService();
        try {
            s.unparkVehicle("WRONG");
            throw new RuntimeException("Test Failed");
        } catch (InvalidTicketException e) { }
    }

    static void testRepeatedExit() {
        ParkingLotService s = setupService();
        Ticket t = s.parkVehicle(new Vehicle("V1", "Red", VehicleType.CAR));
        s.unparkVehicle(t.getTicketId());
        try {
            s.unparkVehicle(t.getTicketId());
            throw new RuntimeException("Test Failed");
        } catch (InvalidTicketException e) { }
    }

    static void testDisplayFreeSlots() {
        ParkingLotService s = setupService();
        s.displayFreeSlots(VehicleType.CAR);
    }
}
