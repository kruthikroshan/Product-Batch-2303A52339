# Parking Lot UML Diagram

```mermaid
classDiagram
    class VehicleType {
        <<enumeration>>
        BIKE
        CAR
        TRUCK
    }

    class Vehicle {
        -String registrationNumber
        -String color
        -VehicleType type
        +getRegistrationNumber() String
        +getColor() String
        +getType() VehicleType
    }

    class ParkingSlot {
        -int floorNumber
        -int slotNumber
        -VehicleType allowedVehicleType
        -boolean isFree
        -Vehicle vehicle
        +parkVehicle(Vehicle)
        +removeVehicle()
        +isFree() boolean
    }

    class ParkingFloor {
        -int floorNumber
        -List~ParkingSlot~ slots
        +addSlot(ParkingSlot)
        +getSlots() List~ParkingSlot~
    }

    class ParkingLot {
        -String parkingLotId
        -List~ParkingFloor~ floors
        +addFloor(ParkingFloor)
        +getFloors() List~ParkingFloor~
    }

    class Ticket {
        -String ticketId
        -Vehicle vehicle
        -ParkingSlot parkingSlot
        -LocalDateTime entryTime
        +getTicketId() String
    }

    class SlotAllocationStrategy {
        <<interface>>
        +findSlot(ParkingLot, VehicleType) ParkingSlot
    }

    class NearestSlotAllocationStrategy {
        +findSlot(ParkingLot, VehicleType) ParkingSlot
    }

    class FeeStrategy {
        <<interface>>
        +calculateFee(Ticket, LocalDateTime) double
    }

    class DefaultFeeStrategy {
        +calculateFee(Ticket, LocalDateTime) double
    }
    
    class FeeStrategyFactory {
        +getFeeStrategy() FeeStrategy
    }

    class ParkingLotService {
        -ParkingLot parkingLot
        -SlotAllocationStrategy allocationStrategy
        -Map~String, Ticket~ activeTickets
        +parkVehicle(Vehicle) Ticket
        +unparkVehicle(String) double
        +displayFreeSlots(VehicleType)
    }

    SlotAllocationStrategy <|.. NearestSlotAllocationStrategy
    FeeStrategy <|.. DefaultFeeStrategy
    
    ParkingLotService --> ParkingLot
    ParkingLotService --> SlotAllocationStrategy
    ParkingLot "1" *-- "*" ParkingFloor
    ParkingFloor "1" *-- "*" ParkingSlot
    ParkingSlot o-- Vehicle
    Ticket --> Vehicle
    Ticket --> ParkingSlot
    FeeStrategyFactory ..> FeeStrategy : creates
```
