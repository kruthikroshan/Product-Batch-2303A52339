import os

base = r"c:\Users\kruth\Downloads\StudentName_Week1\LLD\ParkingLotJava\src"

files = {
    "main/java/com/parkinglot/enums/VehicleType.java": """package com.parkinglot.enums;

public enum VehicleType {
    BIKE, CAR, TRUCK
}
""",
    "main/java/com/parkinglot/models/Vehicle.java": """package com.parkinglot.models;
import com.parkinglot.enums.VehicleType;

public class Vehicle {
    private String registrationNumber;
    private String color;
    private VehicleType type;

    public Vehicle(String registrationNumber, String color, VehicleType type) {
        this.registrationNumber = registrationNumber;
        this.color = color;
        this.type = type;
    }

    public String getRegistrationNumber() { return registrationNumber; }
    public VehicleType getType() { return type; }
    public String getColor() { return color; }
}
""",
    "main/java/com/parkinglot/models/ParkingSlot.java": """package com.parkinglot.models;
import com.parkinglot.enums.VehicleType;

public class ParkingSlot {
    private int floorNumber;
    private int slotNumber;
    private VehicleType allowedVehicleType;
    private boolean isFree;
    private Vehicle vehicle;

    public ParkingSlot(int floorNumber, int slotNumber, VehicleType allowedVehicleType) {
        this.floorNumber = floorNumber;
        this.slotNumber = slotNumber;
        this.allowedVehicleType = allowedVehicleType;
        this.isFree = true;
    }

    public boolean isFree() { return isFree; }
    public VehicleType getAllowedVehicleType() { return allowedVehicleType; }
    public int getFloorNumber() { return floorNumber; }
    public int getSlotNumber() { return slotNumber; }
    public Vehicle getVehicle() { return vehicle; }

    public void parkVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
        this.isFree = false;
    }

    public void removeVehicle() {
        this.vehicle = null;
        this.isFree = true;
    }
}
""",
    "main/java/com/parkinglot/models/ParkingFloor.java": """package com.parkinglot.models;
import com.parkinglot.enums.VehicleType;
import java.util.ArrayList;
import java.util.List;

public class ParkingFloor {
    private int floorNumber;
    private List<ParkingSlot> slots;

    public ParkingFloor(int floorNumber) {
        this.floorNumber = floorNumber;
        this.slots = new ArrayList<>();
    }

    public void addSlot(ParkingSlot slot) {
        slots.add(slot);
    }

    public List<ParkingSlot> getSlots() { return slots; }
    public int getFloorNumber() { return floorNumber; }
}
""",
    "main/java/com/parkinglot/models/ParkingLot.java": """package com.parkinglot.models;
import java.util.ArrayList;
import java.util.List;

public class ParkingLot {
    private String parkingLotId;
    private List<ParkingFloor> floors;

    public ParkingLot(String parkingLotId) {
        this.parkingLotId = parkingLotId;
        this.floors = new ArrayList<>();
    }

    public void addFloor(ParkingFloor floor) {
        floors.add(floor);
    }

    public List<ParkingFloor> getFloors() { return floors; }
    public String getParkingLotId() { return parkingLotId; }
}
""",
    "main/java/com/parkinglot/models/Ticket.java": """package com.parkinglot.models;
import java.time.LocalDateTime;

public class Ticket {
    private String ticketId;
    private Vehicle vehicle;
    private ParkingSlot parkingSlot;
    private LocalDateTime entryTime;

    public Ticket(String ticketId, Vehicle vehicle, ParkingSlot parkingSlot, LocalDateTime entryTime) {
        this.ticketId = ticketId;
        this.vehicle = vehicle;
        this.parkingSlot = parkingSlot;
        this.entryTime = entryTime;
    }

    public String getTicketId() { return ticketId; }
    public Vehicle getVehicle() { return vehicle; }
    public ParkingSlot getParkingSlot() { return parkingSlot; }
    public LocalDateTime getEntryTime() { return entryTime; }
}
""",
    "main/java/com/parkinglot/exceptions/DuplicateVehicleException.java": """package com.parkinglot.exceptions;

public class DuplicateVehicleException extends RuntimeException {
    public DuplicateVehicleException(String message) { super(message); }
}
""",
    "main/java/com/parkinglot/exceptions/InvalidTicketException.java": """package com.parkinglot.exceptions;

public class InvalidTicketException extends RuntimeException {
    public InvalidTicketException(String message) { super(message); }
}
""",
    "main/java/com/parkinglot/exceptions/SlotUnavailableException.java": """package com.parkinglot.exceptions;

public class SlotUnavailableException extends RuntimeException {
    public SlotUnavailableException(String message) { super(message); }
}
""",
    "main/java/com/parkinglot/strategies/SlotAllocationStrategy.java": """package com.parkinglot.strategies;
import com.parkinglot.models.ParkingLot;
import com.parkinglot.models.ParkingSlot;
import com.parkinglot.enums.VehicleType;

public interface SlotAllocationStrategy {
    ParkingSlot findSlot(ParkingLot parkingLot, VehicleType vehicleType);
}
""",
    "main/java/com/parkinglot/strategies/NearestSlotAllocationStrategy.java": """package com.parkinglot.strategies;
import com.parkinglot.models.ParkingFloor;
import com.parkinglot.models.ParkingLot;
import com.parkinglot.models.ParkingSlot;
import com.parkinglot.enums.VehicleType;
import com.parkinglot.exceptions.SlotUnavailableException;

public class NearestSlotAllocationStrategy implements SlotAllocationStrategy {
    @Override
    public ParkingSlot findSlot(ParkingLot parkingLot, VehicleType vehicleType) {
        for (ParkingFloor floor : parkingLot.getFloors()) {
            for (ParkingSlot slot : floor.getSlots()) {
                if (slot.isFree() && slot.getAllowedVehicleType() == vehicleType) {
                    return slot;
                }
            }
        }
        throw new SlotUnavailableException("No free slots available for " + vehicleType);
    }
}
""",
    "main/java/com/parkinglot/strategies/FeeStrategy.java": """package com.parkinglot.strategies;
import com.parkinglot.models.Ticket;
import java.time.LocalDateTime;

public interface FeeStrategy {
    double calculateFee(Ticket ticket, LocalDateTime exitTime);
}
""",
    "main/java/com/parkinglot/strategies/DefaultFeeStrategy.java": """package com.parkinglot.strategies;
import com.parkinglot.models.Ticket;
import java.time.LocalDateTime;
import java.time.Duration;

public class DefaultFeeStrategy implements FeeStrategy {
    @Override
    public double calculateFee(Ticket ticket, LocalDateTime exitTime) {
        long hours = Duration.between(ticket.getEntryTime(), exitTime).toHours();
        if (hours == 0) hours = 1; // Minimum 1 hour charge
        
        switch (ticket.getVehicle().getType()) {
            case BIKE: return hours * 10.0;
            case CAR: return hours * 20.0;
            case TRUCK: return hours * 50.0;
            default: return 0.0;
        }
    }
}
""",
    "main/java/com/parkinglot/strategies/FeeStrategyFactory.java": """package com.parkinglot.strategies;
// Using Factory Pattern for Fee Strategy
public class FeeStrategyFactory {
    public static FeeStrategy getFeeStrategy() {
        return new DefaultFeeStrategy();
    }
}
""",
    "main/java/com/parkinglot/services/ParkingLotService.java": """package com.parkinglot.services;
import com.parkinglot.models.*;
import com.parkinglot.enums.VehicleType;
import com.parkinglot.strategies.SlotAllocationStrategy;
import com.parkinglot.strategies.FeeStrategyFactory;
import com.parkinglot.exceptions.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.HashSet;
import java.util.Set;

public class ParkingLotService {
    private ParkingLot parkingLot;
    private SlotAllocationStrategy allocationStrategy;
    private Map<String, Ticket> activeTickets = new HashMap<>();
    private Set<String> parkedVehicles = new HashSet<>();
    private int ticketCounter = 1;

    public ParkingLotService(ParkingLot parkingLot, SlotAllocationStrategy allocationStrategy) {
        this.parkingLot = parkingLot;
        this.allocationStrategy = allocationStrategy;
    }

    public Ticket parkVehicle(Vehicle vehicle) {
        if (parkedVehicles.contains(vehicle.getRegistrationNumber())) {
            throw new DuplicateVehicleException("Vehicle is already parked!");
        }

        ParkingSlot slot = allocationStrategy.findSlot(parkingLot, vehicle.getType());
        slot.parkVehicle(vehicle);

        String ticketId = parkingLot.getParkingLotId() + "_" + slot.getFloorNumber() + "_" + slot.getSlotNumber();
        Ticket ticket = new Ticket(ticketId, vehicle, slot, LocalDateTime.now());
        
        activeTickets.put(ticketId, ticket);
        parkedVehicles.add(vehicle.getRegistrationNumber());
        return ticket;
    }

    public double unparkVehicle(String ticketId) {
        if (!activeTickets.containsKey(ticketId)) {
            throw new InvalidTicketException("Invalid or already processed ticket!");
        }

        Ticket ticket = activeTickets.get(ticketId);
        ParkingSlot slot = ticket.getParkingSlot();
        
        slot.removeVehicle();
        activeTickets.remove(ticketId);
        parkedVehicles.remove(ticket.getVehicle().getRegistrationNumber());

        return FeeStrategyFactory.getFeeStrategy().calculateFee(ticket, LocalDateTime.now().plusHours(2)); // Simulating 2 hours
    }

    public void displayFreeSlots(VehicleType vehicleType) {
        for (ParkingFloor floor : parkingLot.getFloors()) {
            System.out.print("Free slots for " + vehicleType + " on Floor " + floor.getFloorNumber() + ": ");
            for (ParkingSlot slot : floor.getSlots()) {
                if (slot.isFree() && slot.getAllowedVehicleType() == vehicleType) {
                    System.out.print(slot.getSlotNumber() + ", ");
                }
            }
            System.out.println();
        }
    }
}
""",
    "main/java/com/parkinglot/Main.java": """package com.parkinglot;
import com.parkinglot.enums.VehicleType;
import com.parkinglot.models.*;
import com.parkinglot.services.ParkingLotService;
import com.parkinglot.strategies.NearestSlotAllocationStrategy;

public class Main {
    public static void main(String[] args) {
        ParkingLot lot = new ParkingLot("PRK1");
        ParkingFloor floor1 = new ParkingFloor(1);
        floor1.addSlot(new ParkingSlot(1, 1, VehicleType.CAR));
        floor1.addSlot(new ParkingSlot(1, 2, VehicleType.CAR));
        floor1.addSlot(new ParkingSlot(1, 3, VehicleType.BIKE));
        
        ParkingFloor floor2 = new ParkingFloor(2);
        floor2.addSlot(new ParkingSlot(2, 1, VehicleType.TRUCK));
        floor2.addSlot(new ParkingSlot(2, 2, VehicleType.CAR));

        lot.addFloor(floor1);
        lot.addFloor(floor2);

        ParkingLotService service = new ParkingLotService(lot, new NearestSlotAllocationStrategy());

        try {
            // 1. Park Car 1
            Vehicle car1 = new Vehicle("KA-01-1234", "Red", VehicleType.CAR);
            Ticket t1 = service.parkVehicle(car1);
            System.out.println("Parked Car 1. Ticket: " + t1.getTicketId());

            // 2. Park Car 2
            Vehicle car2 = new Vehicle("KA-01-5678", "Blue", VehicleType.CAR);
            Ticket t2 = service.parkVehicle(car2);
            System.out.println("Parked Car 2. Ticket: " + t2.getTicketId());

            // 3. Display free CAR slots
            service.displayFreeSlots(VehicleType.CAR);

            // 4. Unpark Car 1
            double fee = service.unparkVehicle(t1.getTicketId());
            System.out.println("Unparked Car 1. Fee: " + fee);

            // 5. Display free CAR slots again
            service.displayFreeSlots(VehicleType.CAR);

            // 6. Test invalid ticket
            try {
                service.unparkVehicle("INVALID_TICKET");
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
            
            // 7. Test repeated exit
            try {
                service.unparkVehicle(t1.getTicketId());
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }

            // 8. Test duplicate vehicle
            try {
                service.parkVehicle(car2);
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
""",
    "test/java/com/parkinglot/ParkingLotServiceTest.java": """package com.parkinglot;
import com.parkinglot.enums.VehicleType;
import com.parkinglot.models.*;
import com.parkinglot.services.ParkingLotService;
import com.parkinglot.strategies.NearestSlotAllocationStrategy;
import com.parkinglot.exceptions.*;

public class ParkingLotServiceTest {
    public static void main(String[] args) {
        testParkVehicleSuccess();
        testDuplicateVehicle();
        testSlotUnavailable();
        testUnparkSuccess();
        testInvalidTicket();
        testRepeatedExit();
        testDisplayFreeSlots();
        System.out.println("All basic tests passed successfully.");
    }

    private static ParkingLotService setupService() {
        ParkingLot lot = new ParkingLot("TEST");
        ParkingFloor floor = new ParkingFloor(1);
        floor.addSlot(new ParkingSlot(1, 1, VehicleType.CAR));
        lot.addFloor(floor);
        return new ParkingLotService(lot, new NearestSlotAllocationStrategy());
    }

    static void testParkVehicleSuccess() {
        ParkingLotService s = setupService();
        Ticket t = s.parkVehicle(new Vehicle("V1", "Red", VehicleType.CAR));
        if (t == null) throw new RuntimeException("Test Failed");
    }

    static void testDuplicateVehicle() {
        ParkingLotService s = setupService();
        Vehicle v = new Vehicle("V1", "Red", VehicleType.CAR);
        s.parkVehicle(v);
        try {
            s.parkVehicle(v);
            throw new RuntimeException("Test Failed");
        } catch (DuplicateVehicleException e) { }
    }

    static void testSlotUnavailable() {
        ParkingLotService s = setupService();
        s.parkVehicle(new Vehicle("V1", "Red", VehicleType.CAR));
        try {
            s.parkVehicle(new Vehicle("V2", "Blue", VehicleType.CAR));
            throw new RuntimeException("Test Failed");
        } catch (SlotUnavailableException e) { }
    }

    static void testUnparkSuccess() {
        ParkingLotService s = setupService();
        Ticket t = s.parkVehicle(new Vehicle("V1", "Red", VehicleType.CAR));
        s.unparkVehicle(t.getTicketId());
    }

    static void testInvalidTicket() {
        ParkingLotService s = setupService();
        try {
            s.unparkVehicle("WRONG");
            throw new RuntimeException("Test Failed");
        } catch (InvalidTicketException e) { }
    }

    static void testRepeatedExit() {
        ParkingLotService s = setupService();
        Ticket t = s.parkVehicle(new Vehicle("V1", "Red", VehicleType.CAR));
        s.unparkVehicle(t.getTicketId());
        try {
            s.unparkVehicle(t.getTicketId());
            throw new RuntimeException("Test Failed");
        } catch (InvalidTicketException e) { }
    }

    static void testDisplayFreeSlots() {
        ParkingLotService s = setupService();
        s.displayFreeSlots(VehicleType.CAR);
    }
}
"""
}

for path, content in files.items():
    full_path = os.path.join(base, path.replace('/', os.sep))
    os.makedirs(os.path.dirname(full_path), exist_ok=True)
    with open(full_path, "w") as f:
        f.write(content)
